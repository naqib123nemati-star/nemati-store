"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { getDictionary } from "@/lib/i18n";
import { LayoutDashboard, Package, Tags, ShoppingCart, Users, LogOut } from "lucide-react";

export default function AdminSidebar({ locale, role }: { locale: string; role: string }) {
  const t = getDictionary(locale);
  const pathname = usePathname();
  const base = `/${locale}/admin`;

  const links = [
    { href: base, label: t.admin.dashboard, icon: LayoutDashboard },
    { href: `${base}/products`, label: t.admin.products, icon: Package },
    { href: `${base}/categories`, label: t.admin.categories, icon: Tags },
    { href: `${base}/orders`, label: t.admin.orders, icon: ShoppingCart },
    ...(role === "SUPER_ADMIN" ? [{ href: `${base}/admins`, label: t.admin.admins, icon: Users }] : [])
  ];

  return (
    <aside className="hidden w-64 shrink-0 border-e border-cream-200 bg-white p-6 md:block">
      <div className="mb-8 flex items-center gap-2">
        <img src="/images/logo.png" alt="" className="h-9 w-9 object-contain" />
        <span className="font-bold">{t.brand}</span>
      </div>

      <nav className="space-y-1">
        {links.map((link) => {
          const Icon = link.icon;
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium ${
                active ? "bg-gold-500/10 text-gold-600" : "text-ink-700 hover:bg-cream-100"
              }`}
            >
              <Icon className="h-4 w-4" />
              {link.label}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={() => signOut({ callbackUrl: `/${locale}/admin/login` })}
        className="mt-8 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50"
      >
        <LogOut className="h-4 w-4" />
        {t.admin.logout}
      </button>
    </aside>
  );
}
